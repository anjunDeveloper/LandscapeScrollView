//
//  TestView.h
//  横向多屏滚动Demo
//
//  Created by 安俊 on 16/2/23.
//  Copyright © 2016年 anjun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestView : UIView

/** 顶部tab菜单 */
@property (nonatomic, strong) UIView * topMenuView;
/** 可滑动的slider视图 */
@property (nonatomic, strong) UIView * menuSliderView;
/** tab数量 */
@property (nonatomic, assign) NSInteger componentNumber;
/** 展示在tab上的文字数组 */
@property (nonatomic, copy) NSArray * titleArr;
/** 是否需要"滑块" */
@property (nonatomic, assign) BOOL hasSlider;
/** 用来放各子图的scrollView */
@property (nonatomic, strong)  UIScrollView * contentMainScroll;
/** 子视图数组(数组中的元素类型是UIView) */
@property (nonatomic, strong) NSMutableArray<UIView *> * subViewsArray;


/**
 *  给定标题数组，决定分为几部分
 *
 *  @param titleArray 标题数组
 *  @param frame      尺寸
 *  @param hasSlider  有无slider
 *
 *  @return 返回的View
 */

- (instancetype)initWithTitleArray:(NSArray *)titleArray frame:(CGRect)frame hasSlider:(BOOL)hasSlider;

@end
