//
//  ViewController.m
//  横向多屏滚动Demo
//
//  Created by 安俊 on 16/2/23.
//  Copyright © 2016年 anjun. All rights reserved.
//

#import "ViewController.h"
#import "TestView.h"
#import "UIView+Extension.h"

#define ScreenW ([UIScreen mainScreen].bounds.size.width)
#define ScreenH ([UIScreen mainScreen].bounds.size.height)

@interface ViewController ()<UITableViewDelegate>
@property (nonatomic, strong) UITableView *table;
@property (nonatomic ,assign) BOOL flag;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    /**
     我喜欢的明星 和 明星广场 下面的视图可以这么处理:
     在test的scrollView中添加View
     */
    TestView * test = [[TestView alloc] initWithTitleArray:@[@"我喜欢的明星",@"明星广场",@"非常星魅力"] frame:CGRectMake(0,50,ScreenW,ScreenH - 50) hasSlider:NO];
    [self.view addSubview:test];
    
    UIView * firstView = [[UIView alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    firstView.backgroundColor = [UIColor cyanColor];
    [test.subViewsArray[0] addSubview:firstView];
    
    
    
    
    
    
//    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
//    [btn setTitle:@"隐藏/显示表头" forState:UIControlStateNormal];
//    [btn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
//    btn.frame = CGRectMake(40, 40, 140, 20);
//    [btn addTarget:self action:@selector(testAction:) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:btn];
//    
//    UITableView * table = [[UITableView alloc] initWithFrame:CGRectMake(0, 80, ScreenW, 300) style:UITableViewStylePlain];
//    table.delegate = self;
//    _table = table;
//    [self.view addSubview:table];
 
}

- (void)testAction:(UIButton *)btn
{
    self.flag = YES;
    [self tableView:_table heightForHeaderInSection:0];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    UIView * headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenW, 80)];
    headView.backgroundColor = [UIColor yellowColor];
    return headView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(self.flag)
    {
        return 0;
    }
    return 80;
}

@end
