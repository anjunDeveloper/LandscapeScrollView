//
//  TestView.m
//  横向多屏滚动Demo
//
//  Created by 安俊 on 16/2/23.
//  Copyright © 2016年 anjun. All rights reserved.
//

#import "TestView.h"
#import "UIView+Extension.h"

@interface TestView ()<UIScrollViewDelegate>

@end

@implementation TestView


- (instancetype)initWithTitleArray:(NSArray *)titleArray frame:(CGRect)frame hasSlider:(BOOL)hasSlider
{
    if(self = [super initWithFrame:frame])
    {
        self.componentNumber = titleArray.count;
        self.titleArr = titleArray;
        self.hasSlider = hasSlider;
        [self creatTopMenu];
        [self creatContentScrollView];
    }
    return self;
}

// 布局
- (void)creatTopMenu
{
    // 创建topView 高度44
    _topMenuView = [[UIView alloc] initWithFrame:CGRectMake(0,0, self.frame.size.width,44)];
    _topMenuView.userInteractionEnabled = YES;
    _topMenuView.hidden = NO;
    [self addSubview:_topMenuView];
    _topMenuView.backgroundColor = [UIColor yellowColor];
    
    
    if(self.hasSlider)
    {
        _menuSliderView = [[UIView alloc] initWithFrame:CGRectMake(0,_topMenuView.height-1.5,self.width/self.componentNumber,2)];
        
        _menuSliderView.backgroundColor = [UIColor redColor];
        [_topMenuView addSubview:_menuSliderView];
    }

    for (int i = 0; i < self.componentNumber; i++) {
        UIButton *Btn = [UIButton buttonWithType:UIButtonTypeCustom];
        Btn.frame = CGRectMake(self.frame.size.width/self.componentNumber*i, 0,self.frame.size.width/self.componentNumber,44);
        [Btn setTitle:_titleArr[i] forState:UIControlStateNormal];
        if(!self.hasSlider)
        {
            [Btn setTitle:[NSString stringWithFormat:@"  %@",_titleArr[i]] forState:UIControlStateNormal];
        }
        [Btn setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
        [Btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        Btn.titleLabel.font = [UIFont systemFontOfSize:15.0];
        
        // 图片开发者自定义
        if(i == 0)
        {
            Btn.selected=YES;
            [Btn setImage:[UIImage imageNamed:@"login_icon_weibo"] forState:UIControlStateNormal];
        }
        else if (i == 1)
        {
            [Btn setImage:[UIImage imageNamed:@"login_icon_QQ"] forState:UIControlStateNormal];
        }
        else if (i == 2)
        {
            [Btn setImage:[UIImage imageNamed:@"login_icon_weibo"] forState:UIControlStateNormal];
        }
        
        Btn.tag = 100 + i;
        [Btn addTarget:self action:@selector(topMenuClick:) forControlEvents:UIControlEventTouchUpInside];
        [_topMenuView addSubview:Btn];
        if(i == 0)
        {
            _menuSliderView.center = CGPointMake(Btn.center.x, _menuSliderView.y);
        }
    }
    
}

#pragma mark  菜单的点击事件
- (void)topMenuClick:(UIButton *)sender
{
    for (UIView * subView in _topMenuView.subviews) {
        if([subView isMemberOfClass:[UIButton class]])
        {
            UIButton * btn = (UIButton *)subView;
            if(btn.tag == sender.tag)
            {
                [_contentMainScroll setContentOffset:CGPointMake(self.width * (btn.tag - 100), 0) animated:NO];
                btn.selected = YES;
                [UIView animateWithDuration:0.3 animations:^{
                    _menuSliderView.center = CGPointMake(sender.center.x,_topMenuView.height-1.5);
                }];
            }
            else
            {
                btn.selected = NO;
            }
        }
    }
}

#pragma mark 创建滑动视图
- (void)creatContentScrollView
{
    _contentMainScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0,_topMenuView.bottom, self.width, self.height)]; // 多留10个单位好看一些

    _contentMainScroll.hidden = NO;
    _contentMainScroll.contentSize = CGSizeMake(self.width*self.componentNumber, CGRectGetHeight(_contentMainScroll.frame));
    _contentMainScroll.scrollEnabled = YES; // 是否禁用左右滑动的手势
    _contentMainScroll.delegate = self;
    _contentMainScroll.bounces = NO;
    _contentMainScroll.showsHorizontalScrollIndicator = NO;
    _contentMainScroll.showsVerticalScrollIndicator = NO;
    
    [self addSubview:_contentMainScroll];
    
    _contentMainScroll.backgroundColor = [UIColor cyanColor];
    _contentMainScroll.pagingEnabled = YES;
    
    self.subViewsArray = [NSMutableArray array];
    for (int i = 0; i < self.componentNumber; i++) {
        UIView * myView = [[UIView alloc]initWithFrame:CGRectMake(self.width*i, 0, self.width, _contentMainScroll.height)];
        [_contentMainScroll addSubview:myView];
        [self.subViewsArray addObject:myView];
        
        myView.backgroundColor = [UIColor colorWithRed:arc4random()%256/255.0 green:arc4random()%256/255.0 blue:arc4random()%256/255.0 alpha:1.0];
    }
}


#pragma mark - scrollView delegate
//滚动视图释放滚动
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if (scrollView == _contentMainScroll) {
        //调整顶部滑条按钮状态
        int tag = (int)scrollView.contentOffset.x/self.width + 100;
        UIButton * btn = (UIButton *)[_topMenuView viewWithTag:tag];
        [self topMenuClick:btn];
    }
}


@end
